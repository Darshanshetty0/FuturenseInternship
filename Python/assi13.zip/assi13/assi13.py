# Test script for all the modules and packages
if __name__ == "__main__":
    # Testing math_utils
    import math_utils
    print("Sum of 5 and 3:", math_utils.add(5, 3))

    # Testing string_utils
    import string_util
    print("Uppercase 'hello':", string_util.to_uppercase('hello'))
    print("Lowercase 'WORLD':", string_util.to_lowercase('WORLD'))

    # Testing geometry package
    from geometry.shapes import Rectangle, Circle
    from geometry.operations import area, perimeter
    rect = Rectangle(10, 5)
    circ = Circle(7)
    print("Rectangle area:", area(rect))
    print("Rectangle perimeter:", perimeter(rect))
    print("Circle area:", area(circ))
    print("Circle circumference:", perimeter(circ))

    # Testing file_utils
    import file_utils
    file_utils.write_file('test.txt', 'Hello, World!')
    print("Content of 'test.txt':", file_utils.read_file('test.txt'))

    # Testing calculator package
    from calculator.operations import add, subtract, multiply, divide
    print("10 + 5:", add(10, 5))
    print("10 - 5:", subtract(10, 5))
    print("10 * 5:", multiply(10, 5))
    print("10 / 5:", divide(10, 5))

    # Testing date_utils
    import date_utils
    print("Current date and time:", date_utils.current_date_time())

    # Testing shapes package
    from shapes.triangles import Triangle
    tri = Triangle(3, 4, 3, 4, 5)
    print("Triangle area:", tri.area())
    print("Triangle perimeter:", tri.perimeter())
