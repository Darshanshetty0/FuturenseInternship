from datetime import datetime

def current_date_time():
    return datetime.now()