def to_uppercase(string):
    return string.upper()

def to_lowercase(string):
    return string.lower()