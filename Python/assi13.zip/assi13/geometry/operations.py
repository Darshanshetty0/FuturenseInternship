from geometry.shapes import Rectangle, Circle

def area(shape):
    return shape.area()

def perimeter(shape):
    if isinstance(shape, Rectangle):
        return shape.perimeter()
    elif isinstance(shape, Circle):
        return shape.circumference()